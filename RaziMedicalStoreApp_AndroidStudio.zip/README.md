# Razi Medical Store — Android App

A buildable Jetpack Compose Android Studio project based on the supplied app-flow image.

## Included
- Customer home dashboard
- Medicine search
- Medicine details
- Cart with quantity controls
- Checkout with address/payment selection
- Orders screen
- Admin dashboard
- Medicine inventory
- Add medicine form
- Order status management
- Sales report / top-selling medicines
- Local demo data and in-memory cart/order state

## Important
This version is a real, runnable Android app, but it is a local/offline prototype. It does not yet connect to a live database, payment gateway, authentication, or server.

For a production deployment, connect Firebase/your own backend for:
- customer accounts
- cloud medicine inventory
- real-time stock
- order sync
- admin authentication
- Razorpay/UPI payment processing
- notifications

## Build
Open the folder in Android Studio, let Gradle sync, then Run on an Android device/emulator.

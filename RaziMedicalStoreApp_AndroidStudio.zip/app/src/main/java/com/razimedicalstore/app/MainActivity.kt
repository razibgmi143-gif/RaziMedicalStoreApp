package com.razimedicalstore.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF08783E)
private val LightGreen = Color(0xFFEAF7EF)

data class Medicine(
    val id: Int,
    val name: String,
    val company: String,
    val category: String,
    val price: Double,
    val stock: Int
)

data class CartLine(val medicine: Medicine, var qty: Int)
data class StoreOrder(val id: Int, val customer: String, val total: Double, var status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RaziApp() }
    }
}

@Composable
fun RaziApp() {
    var medicines by remember {
        mutableStateOf(
            listOf(
                Medicine(1,"Crocin 650 Tablet","GSK","Pain Relief",15.0,120),
                Medicine(2,"Dolo 650 Tablet","Micro Labs","Fever",10.0,80),
                Medicine(3,"Azithral 500 Tablet","Alembic","Antibiotic",45.0,5),
                Medicine(4,"Calpol 650 Tablet","GSK","Pain Relief",12.0,160),
                Medicine(5,"Amoxycillin 500 Capsule","Cipla","Antibiotic",30.0,0)
            )
        )
    }
    var cart by remember { mutableStateOf(listOf<CartLine>()) }
    var orders by remember {
        mutableStateOf(
            listOf(
                StoreOrder(1001,"Ramesh Kumar",450.0,"Pending"),
                StoreOrder(1002,"Sunil Kumar",230.0,"Delivered"),
                StoreOrder(1003,"Ravi Raj",120.0,"Pending")
            )
        )
    }
    var mode by remember { mutableStateOf("Customer") }
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Medicine?>(null) }
    var showCheckout by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = Green,
            background = Color(0xFFF7FAF8),
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Razi Medical Store", fontWeight = FontWeight.Bold)
                            Text(if (mode=="Customer") "Customer App" else "Owner / Admin Panel",
                                fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { mode = if(mode=="Customer") "Admin" else "Customer"; tab=0 }) {
                            Icon(Icons.Default.Menu, "Switch panel")
                        }
                    },
                    actions = {
                        if (mode=="Customer") {
                            BadgedBox(badge = {
                                if (cart.sumOf { it.qty } > 0)
                                    Badge { Text(cart.sumOf { it.qty }.toString()) }
                            }) {
                                IconButton(onClick = { tab=2 }) { Icon(Icons.Default.ShoppingCart, "Cart") }
                            }
                        } else {
                            IconButton(onClick = { mode="Customer"; tab=0 }) {
                                Icon(Icons.Default.Person, "Customer")
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    val labels = if (mode=="Customer")
                        listOf("Home","Search","Cart","Orders")
                    else listOf("Dashboard","Medicines","Add","Orders","Reports")
                    val icons = if (mode=="Customer")
                        listOf(Icons.Default.Home,Icons.Default.Search,Icons.Default.ShoppingCart,Icons.Default.ReceiptLong)
                    else listOf(Icons.Default.Dashboard,Icons.Default.MedicalServices,Icons.Default.Add,Icons.Default.ReceiptLong,Icons.Default.BarChart)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab==i,
                            onClick = { tab=i },
                            icon = { Icon(icons[i], null) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                if (mode=="Customer") {
                    when(tab) {
                        0 -> CustomerHome(medicines) { selected=it }
                        1 -> SearchScreen(medicines) { selected=it }
                        2 -> CartScreen(cart, onQty={m,q ->
                            cart = cart.map { if(it.medicine.id==m.id) it.copy(qty=q) else it }.filter { it.qty>0 }
                        }, onCheckout={ showCheckout=true })
                        3 -> OrdersScreen(orders)
                    }
                } else {
                    when(tab) {
                        0 -> AdminDashboard(medicines, orders)
                        1 -> MedicineList(medicines) { selected=it }
                        2 -> AddMedicineScreen { m ->
                            medicines = medicines + m.copy(id=(medicines.maxOfOrNull{it.id} ?: 0)+1)
                            tab=1
                        }
                        3 -> AdminOrders(orders) { id,status ->
                            orders = orders.map { if(it.id==id) it.copy(status=status) else it }
                        }
                        4 -> ReportsScreen(medicines, orders)
                    }
                }
            }
        }

        if (selected != null) {
            MedicineDetail(
                medicine=selected!!,
                onDismiss={selected=null},
                onAdd={
                    val old = cart.find { it.medicine.id == selected!!.id }
                    cart = if(old==null) cart + CartLine(selected!!,1)
                           else cart.map { if(it.medicine.id==selected!!.id) it.copy(qty=it.qty+1) else it }
                    selected=null
                }
            )
        }

        if (showCheckout) {
            CheckoutScreen(
                cart=cart,
                onClose={showCheckout=false},
                onPlaceOrder={
                    val total = cart.sumOf { it.medicine.price * it.qty } + 20
                    orders = listOf(StoreOrder((orders.maxOfOrNull{it.id} ?: 1000)+1,"Customer",total,"Pending")) + orders
                    cart = emptyList()
                    showCheckout=false
                    tab=3
                }
            )
        }
    }
}

@Composable
fun CustomerHome(meds: List<Medicine>, onOpen:(Medicine)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Green), shape=RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Save More on Medicines", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold)
                    Text("Quality medicines • Trusted care", color=Color.White)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=Color.White, contentColor=Green)) {
                        Text("Shop Now")
                    }
                }
            }
        }
        item {
            Text("Quick Access", fontWeight=FontWeight.Bold, fontSize=18.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                QuickIcon(Icons.Default.Search,"Search")
                QuickIcon(Icons.Default.MedicalServices,"All Medicines")
                QuickIcon(Icons.Default.ShoppingCart,"Quick Order")
            }
        }
        item { Text("Popular Medicines", fontWeight=FontWeight.Bold, fontSize=18.sp) }
        items(meds.filter{it.stock>0}.take(4)) { med -> MedicineCard(med,onOpen) }
    }
}

@Composable
fun QuickIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label:String) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Surface(shape=RoundedCornerShape(14.dp), color=LightGreen) {
            Icon(icon,null,Modifier.padding(14.dp),tint=Green)
        }
        Text(label,fontSize=11.sp)
    }
}

@Composable
fun SearchScreen(meds:List<Medicine>, onOpen:(Medicine)->Unit) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search medicine")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(meds.filter{it.name.contains(q,true)||it.category.contains(q,true)}) { MedicineCard(it,onOpen) }
        }
    }
}

@Composable
fun MedicineCard(m:Medicine,onOpen:(Medicine)->Unit) {
    Card(onClick={onOpen(m)},Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Surface(Modifier.size(54.dp),shape=RoundedCornerShape(10.dp),color=LightGreen) {
                Box(contentAlignment=Alignment.Center){ Icon(Icons.Default.Medication,null,tint=Green) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(m.name,fontWeight=FontWeight.Bold)
                Text(m.company,fontSize=12.sp,color=Color.Gray)
                Text("₹ %.2f • Stock: %d".format(m.price,m.stock),fontSize=13.sp,color=Green)
            }
            Icon(Icons.Default.ChevronRight,null)
        }
    }
}

@Composable
fun MedicineDetail(medicine:Medicine,onDismiss:()->Unit,onAdd:()->Unit) {
    AlertDialog(
        onDismissRequest=onDismiss,
        confirmButton={Button(onClick=onAdd,enabled=medicine.stock>0){Text("Add to Cart")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Close")}},
        title={Text(medicine.name)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("${medicine.company} • ${medicine.category}")
                Text("Price: ₹%.2f".format(medicine.price),fontWeight=FontWeight.Bold)
                Text(if(medicine.stock>0) "In Stock (${medicine.stock})" else "Out of Stock",
                    color=if(medicine.stock>0) Green else MaterialTheme.colorScheme.error)
                Text("Use medicines only as directed by a qualified healthcare professional.")
            }
        }
    )
}

@Composable
fun CartScreen(cart:List<CartLine>,onQty:(Medicine,Int)->Unit,onCheckout:()->Unit) {
    val subtotal=cart.sumOf{it.medicine.price*it.qty}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("My Cart (${cart.sumOf{it.qty}})",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if(cart.isEmpty()) {
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("Your cart is empty")}
        } else {
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(cart) { line ->
                    Card {
                        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)){
                                Text(line.medicine.name,fontWeight=FontWeight.Bold)
                                Text("₹%.2f each".format(line.medicine.price))
                            }
                            IconButton(onClick={onQty(line.medicine,line.qty-1)}){Text("−",fontSize=22.sp)}
                            Text(line.qty.toString(),fontWeight=FontWeight.Bold)
                            IconButton(onClick={onQty(line.medicine,line.qty+1)}){Text("+",fontSize=22.sp)}
                        }
                    }
                }
            }
            Text("Subtotal: ₹%.2f".format(subtotal),fontWeight=FontWeight.Bold)
            Text("Delivery: ₹20")
            Button(onClick=onCheckout,Modifier.fillMaxWidth(),enabled=cart.isNotEmpty()){Text("Proceed to Checkout")}
        }
    }
}

@Composable
fun CheckoutScreen(cart:List<CartLine>,onClose:()->Unit,onPlaceOrder:()->Unit) {
    var address by remember { mutableStateOf("Begampur Madarsa Chowk, Begampur, Purnia, Bihar") }
    var payment by remember { mutableStateOf("Cash on Delivery") }
    AlertDialog(
        onDismissRequest=onClose,
        confirmButton={Button(onClick=onPlaceOrder){Text("Place Order")}},
        dismissButton={TextButton(onClick=onClose){Text("Cancel")}},
        title={Text("Checkout")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(address,{address=it},label={Text("Delivery Address")})
                Text("Delivery type",fontWeight=FontWeight.Bold)
                Text("Store Pickup / Self Collect")
                Text("Payment",fontWeight=FontWeight.Bold)
                listOf("Cash on Delivery","UPI / Online Payment").forEach { p ->
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        RadioButton(payment==p,{payment=p})
                        Text(p)
                    }
                }
                Text("Total: ₹%.2f".format(cart.sumOf{it.medicine.price*it.qty}+20),fontWeight=FontWeight.Bold)
            }
        }
    )
}

@Composable
fun OrdersScreen(orders:List<StoreOrder>) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("My Orders",fontSize=22.sp,fontWeight=FontWeight.Bold) }
        items(orders.take(10)) { o ->
            Card {
                Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)){
                        Text("#ORD${o.id}",fontWeight=FontWeight.Bold)
                        Text(o.customer,fontSize=12.sp,color=Color.Gray)
                    }
                    Column(horizontalAlignment=Alignment.End){
                        Text("₹%.2f".format(o.total),fontWeight=FontWeight.Bold)
                        Text(o.status,color=if(o.status=="Delivered") Green else Color(0xFFE08A00))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDashboard(meds:List<Medicine>,orders:List<StoreOrder>) {
    val sales=orders.sumOf{it.total}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Dashboard",fontSize=24.sp,fontWeight=FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Total Sales","₹%.0f".format(sales),Modifier.weight(1f))
                StatCard("Total Orders",orders.size.toString(),Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Medicines",meds.size.toString(),Modifier.weight(1f))
                StatCard("Low Stock",meds.count{it.stock<10}.toString(),Modifier.weight(1f))
            }
        }
        item { Text("Recent Orders",fontWeight=FontWeight.Bold,fontSize=18.sp) }
        items(orders.take(4)) { o -> Card{ Row(Modifier.padding(14.dp)){ Text("#${o.id} ${o.customer}",Modifier.weight(1f)); Text("₹%.0f".format(o.total)) } } }
    }
}

@Composable
fun StatCard(title:String,value:String,modifier:Modifier) {
    Card(modifier) { Column(Modifier.padding(16.dp)){Text(title,fontSize=12.sp,color=Color.Gray);Text(value,fontSize=20.sp,fontWeight=FontWeight.Bold,color=Green)}}
}

@Composable
fun MedicineList(meds:List<Medicine>,onOpen:(Medicine)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item { Text("Medicine Inventory",fontSize=22.sp,fontWeight=FontWeight.Bold) }
        items(meds) { MedicineCard(it,onOpen) }
    }
}

@Composable
fun AddMedicineScreen(onSave:(Medicine)->Unit) {
    var name by remember{mutableStateOf("")}; var company by remember{mutableStateOf("")}
    var category by remember{mutableStateOf("")}; var price by remember{mutableStateOf("")}; var stock by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Add Medicine",fontSize=22.sp,fontWeight=FontWeight.Bold)
        OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Medicine name")})
        OutlinedTextField(company,{company=it},Modifier.fillMaxWidth(),label={Text("Company")})
        OutlinedTextField(category,{category=it},Modifier.fillMaxWidth(),label={Text("Category")})
        OutlinedTextField(price,{price=it},Modifier.fillMaxWidth(),label={Text("Price")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(stock,{stock=it},Modifier.fillMaxWidth(),label={Text("Stock quantity")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        Button(
            onClick={onSave(Medicine(0,name,company,category,price.toDoubleOrNull()?:0.0,stock.toIntOrNull()?:0))},
            enabled=name.isNotBlank() && price.toDoubleOrNull()!=null,
            Modifier.fillMaxWidth()
        ){Text("Save Medicine")}
    }
}

@Composable
fun AdminOrders(orders:List<StoreOrder>,onStatus:(Int,String)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("Orders",fontSize=22.sp,fontWeight=FontWeight.Bold) }
        items(orders) { o ->
            Card {
                Column(Modifier.padding(14.dp)) {
                    Row { Text("#ORD${o.id} • ${o.customer}",Modifier.weight(1f),fontWeight=FontWeight.Bold); Text("₹%.0f".format(o.total)) }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={onStatus(o.id,"Pending")}){Text("Pending")}
                        Button(onClick={onStatus(o.id,"Delivered")}){Text("Delivered")}
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(meds:List<Medicine>,orders:List<StoreOrder>) {
    val sales=orders.sumOf{it.total}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Reports & Analytics",fontSize=22.sp,fontWeight=FontWeight.Bold) }
        item { StatCard("Total Sales","₹%.2f".format(sales),Modifier.fillMaxWidth()) }
        item { Text("Stock Alerts",fontWeight=FontWeight.Bold,fontSize=18.sp) }
        items(meds.filter{it.stock<10}) { m -> Card{Row(Modifier.padding(14.dp)){Text(m.name,Modifier.weight(1f));Text("Stock ${m.stock}",color=MaterialTheme.colorScheme.error)}}}
        item { Text("Top Selling Medicines",fontWeight=FontWeight.Bold,fontSize=18.sp) }
        items(meds.take(4)) { m -> Card{Row(Modifier.padding(14.dp)){Text(m.name,Modifier.weight(1f));Text("₹%.0f".format(m.price))}}}
    }
}
